# Top 100 most expensive football transfers
This project aimed to analyze the data of the most expensive transfers in football history. Beyond the players, it aimed to determine statistics on both clubs and countries that spent the most on those transfers.

That being said, the conclusions found are the following:

1. Chelsea is the club that invested the most money in buying players.

2. Premier League (England's league) is the one that spent the most on buying players.

3. China's league is among the leagues that spent the most on player transfers despite not being a top-10 league (measured by both performance and impact, according to FIFA).
